const cityInput = document.getElementById("city-input");
const searchBtn = document.getElementById("search-btn");
const locationBtn = document.getElementById("location-btn");
const unitToggle = document.getElementById("unit-toggle");

const suggestions = document.getElementById("suggestions");

const loading = document.getElementById("loading");
const errorMessage = document.getElementById("error-message");

const cityName = document.getElementById("city-name");
const temperature = document.getElementById("temperature");
const weatherCondition = document.getElementById("weather-condition");
const weatherIcon = document.getElementById("weather-icon");

const feelsLike = document.getElementById("feels-like");
const humidity = document.getElementById("humidity");
const windSpeed = document.getElementById("wind-speed");

const sunrise = document.getElementById("sunrise");
const sunset = document.getElementById("sunset");

const windDirection = document.getElementById("wind-direction");
const pressure = document.getElementById("pressure");
const visibility = document.getElementById("visibility");
const uvIndex = document.getElementById("uv-index");
const precipitation = document.getElementById("precipitation");


const todayIcon = document.getElementById("today-icon");
const todayCondition = document.getElementById("today-condition");
const todayHigh = document.getElementById("today-high");
const todayLow = document.getElementById("today-low");
const todayRain = document.getElementById("today-rain");

const forecastContainer =
    document.getElementById("forecast-container");

const hourlyContainer =
    document.getElementById("hourly-container");

const historyList =
    document.getElementById("history-list");

const noHistory =
    document.getElementById("no-history");

const clearHistory =
    document.getElementById("clear-history");



let currentUnit = "C";
let currentWeatherData = null;
let currentHourlyData = null;
let currentDailyData = null;
let searchTimer;



function getWeatherInfo(code) {

    const weather = {

        0: ["Clear sky", "☀️"],
        1: ["Mainly clear", "🌤️"],
        2: ["Partly cloudy", "⛅"],
        3: ["Overcast", "☁️"],
        45: ["Fog", "🌫️"],
        48: ["Depositing rime fog", "🌫️"],
        51: ["Light drizzle", "🌦️"],
        53: ["Moderate drizzle", "🌦️"],
        55: ["Dense drizzle", "🌧️"],
        61: ["Slight rain", "🌦️"],
        63: ["Moderate rain", "🌧️"],
        65: ["Heavy rain", "🌧️"],
        71: ["Slight snow", "🌨️"],
        73: ["Moderate snow", "❄️"],
        75: ["Heavy snow", "❄️"],
        80: ["Rain showers", "🌦️"],
        81: ["Moderate rain showers", "🌧️"],
        82: ["Heavy rain showers", "⛈️"],
        95: ["Thunderstorm", "⛈️"],
        96: ["Thunderstorm with hail", "⛈️"],
        99: ["Thunderstorm with heavy hail", "⛈️"]

    };

    return weather[code] || ["Unknown", "❓"];
}



function updateWeatherBackground(code) {

    document.body.classList.remove(
        "clear-weather",
        "cloudy-weather",
        "rainy-weather",
        "stormy-weather"
    );


    if (code === 0) {

        document.body.classList.add(
            "clear-weather"
        );

    } else if (
        code >= 1 &&
        code <= 3
    ) {

        document.body.classList.add(
            "cloudy-weather"
        );

    } else if (
        code >= 51 &&
        code <= 82
    ) {

        document.body.classList.add(
            "rainy-weather"
        );

    } else if (
        code >= 95
    ) {

        document.body.classList.add(
            "stormy-weather"
        );

    }

}



function getWindDirection(degrees) {

    const directions = [
        "N", "NE", "E", "SE",
        "S", "SW", "W", "NW"
    ];

    const index =
        Math.round(degrees / 45) % 8;

    return directions[index];
}



function convertTemperature(celsius) {

    if (currentUnit === "C") {

        return Math.round(celsius);

    }

    return Math.round(
        (celsius * 9 / 5) + 32
    );

}


function formatTime(time) {

    const date = new Date(time);

    return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
    });

}



function showLoading() {

    loading.style.display = "block";

}

function hideLoading() {

    loading.style.display = "none";

}



async function getWeather(
    latitude,
    longitude,
    name
) {

    showLoading();

    errorMessage.textContent = "";

    try {

        const url =
            `https://api.open-meteo.com/v1/forecast?` +
            `latitude=${latitude}` +
            `&longitude=${longitude}` +

            `&current=` +
            `temperature_2m,` +
            `relative_humidity_2m,` +
            `apparent_temperature,` +
            `weather_code,` +
            `wind_speed_10m,` +
            `wind_direction_10m,` +
            `surface_pressure,` +
            `visibility,` +
            `precipitation` +

            `&hourly=` +
            `temperature_2m,` +
            `weather_code,` +
            `wind_speed_10m` +

            `&daily=` +
            `weather_code,` +
            `temperature_2m_max,` +
            `temperature_2m_min,` +
            `sunrise,` +
            `sunset,` +
            `uv_index_max` +

            `&timezone=auto`;


        const response =
            await fetch(url);


        if (!response.ok) {

            throw new Error(
                "Weather data could not be loaded."
            );

        }


        const data =
            await response.json();


        currentWeatherData =
            data.current;

        currentHourlyData =
            data.hourly;

        currentDailyData =
            data.daily;


        displayWeather(name);

        saveToHistory(
            name,
            latitude,
            longitude
        );


    } catch (error) {

        errorMessage.textContent =
            "Unable to get weather data. Please try again.";

        console.error(error);

    } finally {

        hideLoading();

    }

}



function displayWeather(name) {

    const current =
        currentWeatherData;


    const weatherInfo =
        getWeatherInfo(
            current.weather_code
        );



    updateWeatherBackground(
        current.weather_code
    );



    cityName.textContent =
        name;

    temperature.textContent =
        convertTemperature(
            current.temperature_2m
        );

    weatherCondition.textContent =
        weatherInfo[0];

    weatherIcon.textContent =
        weatherInfo[1];



    feelsLike.textContent =
        convertTemperature(
            current.apparent_temperature
        );

    humidity.textContent =
        current.relative_humidity_2m;

    windSpeed.textContent =
        Math.round(
            current.wind_speed_10m
        );



    sunrise.textContent =
        formatTime(
            currentDailyData.sunrise[0]
        );

    sunset.textContent =
        formatTime(
            currentDailyData.sunset[0]
        );



    windDirection.textContent =
        `${getWindDirection(
            current.wind_direction_10m
        )} (${Math.round(
            current.wind_direction_10m
        )}°)`;


    pressure.textContent =
        Math.round(
            current.surface_pressure
        );


    visibility.textContent =
        (
            current.visibility / 1000
        ).toFixed(1);


    uvIndex.textContent =
        currentDailyData
            .uv_index_max[0]
            .toFixed(1);


    precipitation.textContent =
        Number(
            current.precipitation
        ).toFixed(1);



    todayIcon.textContent =
        weatherInfo[1];

    todayCondition.textContent =
        weatherInfo[0];

    todayHigh.textContent =
        `${convertTemperature(
            currentDailyData
                .temperature_2m_max[0]
        )}°`;

    todayLow.textContent =
        `${convertTemperature(
            currentDailyData
                .temperature_2m_min[0]
        )}°`;

    todayRain.textContent =
        `${Number(
            current.precipitation
        ).toFixed(1)} mm`;



    displayHourlyForecast();

    displayDailyForecast();

}



function displayHourlyForecast() {

    hourlyContainer.innerHTML = "";

    const now = new Date();

    let startIndex = 0;


    for (
        let i = 0;
        i < currentHourlyData.time.length;
        i++
    ) {

        const hour =
            new Date(
                currentHourlyData.time[i]
            );


        if (hour >= now) {

            startIndex = i;

            break;

        }

    }


    for (
        let i = startIndex;
        i < startIndex + 24 &&
        i < currentHourlyData.time.length;
        i++
    ) {

        const time =
            currentHourlyData.time[i];

        const temp =
            currentHourlyData
                .temperature_2m[i];

        const code =
            currentHourlyData
                .weather_code[i];

        const wind =
            currentHourlyData
                .wind_speed_10m[i];


        const weatherInfo =
            getWeatherInfo(code);


        const card =
            document.createElement("div");

        card.className =
            "hourly-card";


        card.innerHTML = `

            <div class="hourly-time">
                ${formatTime(time)}
            </div>

            <div class="hourly-icon">
                ${weatherInfo[1]}
            </div>

            <div class="hourly-temp">
                ${convertTemperature(temp)}°
            </div>

            <div class="hourly-wind">
                💨 ${Math.round(wind)} km/h
            </div>

        `;


        hourlyContainer.appendChild(card);

    }

}



function displayDailyForecast() {

    forecastContainer.innerHTML = "";


    for (
        let i = 0;
        i < 5;
        i++
    ) {

        const date =
            new Date(
                currentDailyData.time[i]
            );


        const day =
            date.toLocaleDateString([], {
                weekday: "short"
            });


        const weatherInfo =
            getWeatherInfo(
                currentDailyData
                    .weather_code[i]
            );


        const maxTemp =
            convertTemperature(
                currentDailyData
                    .temperature_2m_max[i]
            );


        const minTemp =
            convertTemperature(
                currentDailyData
                    .temperature_2m_min[i]
            );


        const card =
            document.createElement("div");

        card.className =
            "forecast-card";


        card.innerHTML = `

            <h3>${day}</h3>

            <div class="forecast-icon">
                ${weatherInfo[1]}
            </div>

            <p>
                ${weatherInfo[0]}
            </p>

            <strong>
                ${maxTemp}° / ${minTemp}°
            </strong>

        `;


        forecastContainer.appendChild(card);

    }

}



async function searchCity() {

    const city =
        cityInput.value.trim();


    if (!city) {

        errorMessage.textContent =
            "Please enter a city name.";

        return;

    }


    searchBtn.disabled = true;

    searchBtn.innerHTML =
        "⏳ <span>Searching...</span>";

    suggestions.style.display =
        "none";


    try {

        const url =
            `https://geocoding-api.open-meteo.com/v1/search?` +
            `name=${encodeURIComponent(city)}` +
            `&count=1` +
            `&language=en` +
            `&format=json`;


        const response =
            await fetch(url);

        const data =
            await response.json();


        if (
            !data.results ||
            data.results.length === 0
        ) {

            throw new Error(
                "City not found."
            );

        }


        const result =
            data.results[0];


        const name =
            `${result.name}, ${result.country}`;


        await getWeather(
            result.latitude,
            result.longitude,
            name
        );


    } catch (error) {

        errorMessage.textContent =
            "City not found. Try another city.";

    } finally {

        searchBtn.disabled = false;

        searchBtn.innerHTML =
            "🔍 <span>Search</span>";

    }

}



function getCurrentLocation() {

    if (!navigator.geolocation) {

        errorMessage.textContent =
            "Your browser does not support location.";

        return;

    }


    locationBtn.disabled = true;

    locationBtn.innerHTML =
        "⏳ <span>Getting Location...</span>";


    navigator.geolocation.getCurrentPosition(

        async (position) => {

            const latitude =
                position.coords.latitude;

            const longitude =
                position.coords.longitude;


            try {

                const response =
                    await fetch(
                        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
                    );


                const data =
                    await response.json();


                const address =
                    data.address || {};


                const name =
                    address.city ||
                    address.town ||
                    address.village ||
                    "Current Location";


                await getWeather(
                    latitude,
                    longitude,
                    name
                );


            } catch (error) {

                await getWeather(
                    latitude,
                    longitude,
                    "Current Location"
                );

            }


            locationBtn.disabled = false;

            locationBtn.innerHTML =
                "📍 <span>My Location</span>";

        },


        () => {

            errorMessage.textContent =
                "Location permission was denied or unavailable.";

            locationBtn.disabled = false;

            locationBtn.innerHTML =
                "📍 <span>My Location</span>";

        }

    );

}



cityInput.addEventListener(
    "input",
    () => {

        clearTimeout(searchTimer);

        const query =
            cityInput.value.trim();


        if (query.length < 2) {

            suggestions.style.display =
                "none";

            return;

        }


        searchTimer =
            setTimeout(
                async () => {

                    try {

                        const response =
                            await fetch(
                                `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=5&language=en&format=json`
                            );


                        const data =
                            await response.json();


                        suggestions.innerHTML =
                            "";


                        if (!data.results) {

                            suggestions.style.display =
                                "none";

                            return;

                        }


                        data.results.forEach(
                            result => {

                                const item =
                                    document.createElement(
                                        "div"
                                    );

                                item.className =
                                    "suggestion-item";


                                const city =
                                    document.createElement(
                                        "span"
                                    );

                                city.className =
                                    "suggestion-city";

                                city.textContent =
                                    result.name;


                                const country =
                                    document.createElement(
                                        "span"
                                    );

                                country.className =
                                    "suggestion-country";

                                country.textContent =
                                    `${result.country}` +
                                    (
                                        result.admin1
                                            ? ` • ${result.admin1}`
                                            : ""
                                    );


                                item.appendChild(city);

                                item.appendChild(country);


                                item.addEventListener(
                                    "click",
                                    async () => {

                                        cityInput.value =
                                            result.name;

                                        suggestions.style.display =
                                            "none";


                                        await getWeather(
                                            result.latitude,
                                            result.longitude,
                                            `${result.name}, ${result.country}`
                                        );

                                    }
                                );


                                suggestions.appendChild(
                                    item
                                );

                            }
                        );


                        suggestions.style.display =
                            "block";


                    } catch (error) {

                        console.error(
                            "Autocomplete error:",
                            error
                        );

                    }

                },
                400
            );

    }
);



document.addEventListener(
    "click",
    event => {

        if (
            !event.target.closest(
                ".search-wrapper"
            )
        ) {

            suggestions.style.display =
                "none";

        }

    }
);



unitToggle.addEventListener(
    "click",
    () => {

        currentUnit =
            currentUnit === "C"
                ? "F"
                : "C";


        unitToggle.textContent =
            currentUnit === "C"
                ? "°C / °F"
                : "°F / °C";


        if (currentWeatherData) {

            displayWeather(
                cityName.textContent
            );

        }

    }
);



function saveToHistory(
    name,
    latitude,
    longitude
) {

    let history =
        JSON.parse(
            localStorage.getItem(
                "weatherHistory"
            )
        ) || [];


    history =
        history.filter(
            item =>
                item.name !== name
        );


    history.unshift({

        name: name,
        latitude: latitude,
        longitude: longitude

    });


    history =
        history.slice(0, 5);


    localStorage.setItem(
        "weatherHistory",
        JSON.stringify(history)
    );


    displayHistory();

}



function displayHistory() {

    const history =
        JSON.parse(
            localStorage.getItem(
                "weatherHistory"
            )
        ) || [];


    historyList.innerHTML =
        "";


    if (history.length === 0) {

        noHistory.style.display =
            "block";

        return;

    }


    noHistory.style.display =
        "none";


    history.forEach(
        item => {

            const li =
                document.createElement(
                    "li"
                );


            li.textContent =
                item.name;


            li.addEventListener(
                "click",
                () => {

                    cityInput.value =
                        item.name;


                    getWeather(
                        item.latitude,
                        item.longitude,
                        item.name
                    );

                }
            );


            historyList.appendChild(li);

        }
    );

}



clearHistory.addEventListener(
    "click",
    () => {

        localStorage.removeItem(
            "weatherHistory"
        );

        displayHistory();

    }
);



cityInput.addEventListener(
    "keydown",
    event => {

        if (event.key === "Enter") {

            searchCity();

        }

    }
);



searchBtn.addEventListener(
    "click",
    searchCity
);

locationBtn.addEventListener(
    "click",
    getCurrentLocation
);



displayHistory();